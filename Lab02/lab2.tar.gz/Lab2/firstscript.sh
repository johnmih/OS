#!/bin/bash

GREET="Hello, World!"
echo $GREET
