#!/bin/bash

for i in {1..5};
do
	echo "Number: $i"
done

for COLOR in red green blue;
do
	echo "Color: $COLOR"
done

for FILE in /home/ioannisam/quiz-1/;
do
	echo "File: $FILE"
done
