#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

int count = 0;

void handler(int sig) {

    count++;
    printf("Caught signal %d (SIGINT). Signal count: %d\n", sig, count);

    if (count == 2) {
        // default SIGINT handler
        signal(SIGINT, SIG_DFL);
    }
}

int main() {

	// set signal handler for SIGINT
	if (signal(SIGINT, handler) == SIG_ERR) {
		perror("Error in setting signal handler!");
		return 1;
	}

	while (1) {
		printf("Running... Press Ctrl+C to send SIGINT.\n");
		sleep(1);
	}

	return 0;
}
