#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void handler(int sig) {
    printf("SIGINT signal caught! Exiting gracefully!\n");
    exit(0); // exit the program gracefully
}

int main() {

	// set signal handler for SIGINT
	if (signal(SIGINT, handler) == SIG_ERR) {
		perror("Error in setting signal handler!");
		return 1;
	}

	while (1) {
		printf("Running... Press Ctrl+C to send SIGINT.\n");
		sleep(1);
	}

	return 0;
}
