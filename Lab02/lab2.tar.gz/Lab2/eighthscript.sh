#/bin/bash

NUM=5
echo $NUM
let NUM=NUM+NUM
echo $NUM
