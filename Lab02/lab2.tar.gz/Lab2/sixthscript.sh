#!/bin/bash

FRUITS=("apple", "banana", "cherry")
echo "First fruit: ${FRUITS[0]}"

FRUITS+=("date")

for FRUIT in "${FRUITS[@]}";
do
	echo "Fruit: $FRUIT"
done

echo "Total fruits: ${#fruits[@]}";
