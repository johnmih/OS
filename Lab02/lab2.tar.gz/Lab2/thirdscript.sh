#!/bin/bash

NUM=10
if [ $NUM -gt 5 ];
then
	echo "$NUM is greater than 5"
fi

NAME=ALICE
if [ "$NAME" == "ALICE" ]; 
then
	echo "Hello, Alice!"
fi

if [ "$NAME" != "BOB" ];
then
	echo "You are not Bob."
fi
