#!/bin/bash

date
TIME=$(date +%s)
echo "Current time is: $TIME"

let TIME=TIME+TIME
echo "CUrrent time doubled is: $TIME"

for i in {1..20};
do
	echo "$i"
done
