#/bin/bash

DATE=$(date)
echo "Today's date is: $DATE"

USER=`whoami`
echo "Current user: $USER"

FILES=$(ls -1 $(pwd) | wc -l)
echo "Number of files in the current directory: $FILES"
