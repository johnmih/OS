#! /bin/bash

if [ -d "/etc" ] && [ -f "/etc/passwd" ]; 
then
	echo "Both the /etc directory and the /etc/passwd file exist."
fi

if [ "$USER" == "admin" ] || [ "$USER" == "root" ]; 
then
	echo "You are an administrator."
fi

if [ ! -f "example.txt" ]; 
then
	echo "The file example.txt does not exist."
fi
